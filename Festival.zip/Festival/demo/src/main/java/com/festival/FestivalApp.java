package com.festival;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FestivalApp{
    public static void main(String[] args){
        SpringApplication.run(FestivalApp.class, args);
    }
}
